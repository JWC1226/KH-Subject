// 게임 카드 호버 시 우측 프리뷰 영역에 배경 이미지 표시
document.addEventListener('DOMContentLoaded', function () {
    var previewArea = document.getElementById('gamePreviewArea');
    if (!previewArea) return;

    var cards = document.querySelectorAll('.game-card[data-image]');
    cards.forEach(function (card) {
        card.addEventListener('mouseenter', function () {
            previewArea.style.backgroundImage = "url('" + card.dataset.image + "')";
            previewArea.style.backgroundSize = 'cover';
            previewArea.style.backgroundPosition = 'center';
        });
        card.addEventListener('mouseleave', function () {
            previewArea.style.backgroundImage = '';
        });
    });
});
