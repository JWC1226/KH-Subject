<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modern Dark Game Store</title>

<script src="https://kit.fontawesome.com/3dd9964fc0.js"></script>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/mdgs.css">
</head>

<body>
<jsp:include page="/views/common/header.jsp" />

<main class="container">
    <section class="hero-slider">
        <div class="slider-side prev" id="hidari">
            <span> &larr; </span>
        </div>
        <div class="slider-image" id="slider">
            <img src="${pageContext.request.contextPath}/resources/images/MDGS_Theme.png" alt="메인 광고판" class="main-banner-img">
        </div>
        <div class="slider-side next" id="migi">
            <span> &rarr; </span>
        </div>
    </section>

    <section class="notice-section">
        <div class="notice-urgent" id="important-notice">
            【긴급】서버 점검 안내：02:00 ~ 04:00 게임 접속 불가</div>
        <div class="notice-general" id="normal-notice">
            【이벤트】여름맞이 대규모 할인 이벤트가 시작되었습니다!</div>
    </section>

    <section class="game-content-section">
        <div class="game-list-area">
            <c:if test="${empty gameList}">
                <p>등록된 게임이 없습니다.</p>
            </c:if>
            <c:forEach var="game" items="${gameList}">
                <div class="game-column">
                    <div class="game-category-title">${game.genre}</div>
                    <div class="game-card" data-image="${pageContext.request.contextPath}/${game.imagePath}">
                        <img src="${pageContext.request.contextPath}/${game.imagePath}" alt="${game.title} 대표 이미지" width="250">
                    </div>
                </div>
            </c:forEach>
        </div>

        <aside class="game-preview-area" id="gamePreviewArea">
            <div class="preview-content">
                <p>게임에 마우스를 올려보세요</p>
            </div>
        </aside>
    </section>
</main>

<jsp:include page="/views/common/footer.jsp" />
<script src="${pageContext.request.contextPath}/resources/newFile.js"></script>
</body>
</html>
