<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MDGS - 로그인</title>

<script src="https://kit.fontawesome.com/3dd9964fc0.js"></script>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/mdgs.css">
</head>

<body>
<jsp:include page="/views/common/header.jsp" />

<main class="container">
    <section class="auth-form-section">
        <h2>로그인</h2>

        <c:if test="${not empty errorMsg}">
            <div class="notice-urgent">${errorMsg}</div>
        </c:if>

        <form action="${pageContext.request.contextPath}/login" method="post">
            <div class="form-row">
                <label for="id">아이디</label>
                <input type="text" id="id" name="id" required>
            </div>
            <div class="form-row">
                <label for="password">비밀번호</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">로그인</button>
        </form>

        <p class="form-footer-link">계정이 없으신가요? <a href="${pageContext.request.contextPath}/register">회원가입</a></p>
    </section>
</main>

<jsp:include page="/views/common/footer.jsp" />
</body>
</html>
