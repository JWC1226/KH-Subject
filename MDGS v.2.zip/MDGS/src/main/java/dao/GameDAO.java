package dao;

import config.DBConnection;
import model.Game;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GameDAO {

    // 1. 스토어 전체 게임 조회
    public List<Game> getAllGames() {
        List<Game> list = new ArrayList<>();
        String sql = "SELECT * FROM GAMES";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Game(
                    rs.getInt("Game_ID"),
                    rs.getString("Title"),
                    rs.getString("Genre"),
                    rs.getDouble("Price"),
                    rs.getDate("Release_Date"),
                    rs.getString("Developer"),
                    rs.getString("Image_Path")
                ));
            }
        } catch (SQLException e) {
            System.err.println("게임 조회 오류: " + e.getMessage());
        }
        return list;
    }

    // 2. 게임 구매 및 라이브러리 추가 (트랜잭션 적용)
    public boolean purchaseGame(String userSid, int gameId, double amount, String paymentMethod) {
        String txSql = "INSERT INTO TRANSACTIONS (Tx_ID, User_SID, Total_Amount, Payment_Method, Tx_Date) VALUES (TRANSACTION_SEQ.NEXTVAL, ?, ?, ?, SYSDATE)";
        String libSql = "INSERT INTO USER_LIBRARY (Library_ID, User_SID, Game_ID, Purchase_Date, Playtime_Hours) VALUES (LIBRARY_SEQ.NEXTVAL, ?, ?, SYSDATE, 0)";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // 수동 트랜잭션 전환

            // 시퀀스 대용 간이 번호 생성 및 삽입
            long txId = System.currentTimeMillis() % 1000000;
            long libId = (System.currentTimeMillis() + 1) % 1000000;

            // 2-1. 결제 내역 저장
            try (PreparedStatement pstmt1 = conn.prepareStatement(
                    "INSERT INTO TRANSACTIONS (Tx_ID, User_SID, Total_Amount, Payment_Method, Tx_Date) VALUES (?, ?, ?, ?, SYSDATE)")) {
                pstmt1.setLong(1, txId);
                pstmt1.setString(2, userSid);
                pstmt1.setDouble(3, amount);
                pstmt1.setString(4, paymentMethod);
                pstmt1.executeUpdate();
            }

            // 2-2. 사용자 라이브러리에 저장
            try (PreparedStatement pstmt2 = conn.prepareStatement(
                    "INSERT INTO USER_LIBRARY (Library_ID, User_SID, Game_ID, Purchase_Date, Playtime_Hours) VALUES (?, ?, ?, SYSDATE, 0)")) {
                pstmt2.setLong(1, libId);
                pstmt2.setString(2, userSid);
                pstmt2.setInt(3, gameId);
                pstmt2.executeUpdate();
            }

            conn.commit(); // 트랜잭션 성공
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            System.err.println("구매 트랜잭션 실패 (Rollback 처리): " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    // 3. 게임 리뷰 작성
    public boolean addReview(String userSid, int gameId, double rating, String text) {
        String sql = "INSERT INTO REVIEWS (Review_ID, User_SID, Game_ID, Rating, Review_Text, Review_Date) VALUES (?, ?, ?, ?, ?, SYSDATE)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            long reviewId = System.currentTimeMillis() % 1000000;
            pstmt.setLong(1, reviewId);
            pstmt.setString(2, userSid);
            pstmt.setInt(3, gameId);
            pstmt.setDouble(4, rating);
            pstmt.setString(5, text);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("리뷰 작성 오류: " + e.getMessage());
            return false;
        }
    }
}