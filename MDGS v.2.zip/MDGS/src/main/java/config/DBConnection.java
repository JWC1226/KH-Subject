package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	// ojdbc11 드라이버 클래스명
    private static final String DRIVER = "oracle.jdbc.OracleDriver";
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; // 또는 :orcl, @localhost:1521/XEPDB1
    private static final String USER = "C##MDGS"; // DB 사용자명
    private static final String PASS = "mdgs"; // DB 비밀번호 (Oracle은 대소문자 구분됨)

    
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.out.println("DB 연결 실패, Build Path or 접속 정보를 확인하세요: " + e.getMessage());
            throw new SQLException("드라이버 로드 실패", e);
        }

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("오라클 DB 연결 성공: " + conn);
            return conn;
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! Build Path or 접속 정보를 확인하세요");
            e.printStackTrace();
            throw e; // 호출자가 실패를 알 수 있도록 다시 던짐
        }
    }
}