package view;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Sign {
    public static void main(String[] args) {
        // 합쳐진 메서드 실행
        signConsoleToFile();
    }
//
    public static void signConsoleToFile() {	//메소드 압축
        String fileName = "SignData.txt";
        
        try (Scanner scanner = new Scanner(System.in);	//콘솔창 입력
             BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {	//누적된 텍스트값:True

            // i = 1 고정, i <= n(이 값이 변동되면 정의되는 문자수가 변동)
            for (int i = 1; i <= 1; i++) {
                System.out.print("ID, 비밀번호, 이름을 입력해주세요: ");	//공백 허용됨
                String input = scanner.nextLine();
/*                
                // 사용자가 중간에 'exit'를 입력하면 즉시 반복문을 빠져나감
                if (input.equalsIgnoreCase("exit")) {
                    System.out.println("입력을 취소하고 프로그램을 종료합니다.");
                    break; 
                }
*/                
                // 입력받은 값을 파일에 기록
                writer.write(input);
                writer.newLine();
                
                // n 번째 입력이 방금 끝났다면 자동 종료 안내 문구 출력
                if (i == 1) {
                    System.out.println("회원가입이 완료되었습니다");
                }
            }
        } catch (IOException e) {
            System.err.println("파일을 쓰는 중 오류가 발생했습니다: " + e.getMessage());
        }
    }
}