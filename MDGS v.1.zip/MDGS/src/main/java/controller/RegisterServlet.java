package controller;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;

//controller/RegisterServlet.java
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
 private UserDAO userDAO = new UserDAO();

 protected void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
     String id = req.getParameter("id");

     if (userDAO.isDuplicateId(id)) {
         req.setAttribute("errorMsg", "중복된 ID입니다.");
         req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
         return;
     }

     User newUser = new User(
         generateUserSid(), id,
         req.getParameter("password"),
         req.getParameter("email"),
         Integer.parseInt(req.getParameter("age")),
         req.getParameter("address"),
         req.getParameter("cardNum")
     );

     if (userDAO.register(newUser)) {
         resp.sendRedirect(req.getContextPath() + "/login");
     }
 }
}
