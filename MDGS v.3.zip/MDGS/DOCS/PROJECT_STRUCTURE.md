# MDGS 프로젝트 구조 문서

Modern Dark Game Store (MDGS) — Servlet/JSP 기반 게임 스토어 웹앱.
Eclipse Dynamic Web Project / Tomcat 10.1 / Jakarta EE 10 (`jakarta.servlet.*`) / Java 17 / Oracle DB.
Context root: `mdgs` → 접속 주소 `http://localhost:8888/mdgs/`

이 문서는 "무엇이 어디에 있는가"를 표로 정리한 참고 문서입니다. "왜/어떻게 동작하는가"를 코드와 함께 설명한 문서는 [FEATURES_GUIDE.md](FEATURES_GUIDE.md)를 참고하세요.

현재 구현된 기능: **로그인 / 회원가입 / 로그아웃 / 게임 목록 열람 / 게임 검색 / 게임 상세 페이지 / 마이페이지(계정 정보 수정·회원 탈퇴·장바구니 목업) / 고객지원(관리자 전용 회원 조회 포함)**. 실제 구매·결제, 리뷰 작성은 아직 구현되어 있지 않습니다 (7번 항목 참고).

---

## 1. 전체 디렉터리 구조

```
MDGS/
├── DOCS/                                  ← 이 문서와 FEATURES_GUIDE.md가 있는 폴더
├── sql/
│   └── schema.sql                         ← DB 테이블/시드 데이터 스크립트
├── src/main/java/                         ← 자바 소스 루트
│   ├── config/
│   │   └── DBConnection.java              ← Oracle DB 연결
│   ├── controller/                        ← 서블릿 (요청 처리)
│   │   ├── GameListServlet.java           ← "" (홈) + /GameListServlet + 검색(q 파라미터)
│   │   ├── GameDetailServlet.java         ← /gameDetail (게임 상세 조회)
│   │   ├── LoginServlet.java
│   │   ├── LogoutServlet.java
│   │   ├── RegisterServlet.java
│   │   ├── MyPageServlet.java             ← /mypage (계정 수정 / 회원 탈퇴)
│   │   └── SupportServlet.java            ← /support (고객지원, 관리자 전용 회원 조회)
│   ├── dao/                               ← DB 접근 계층
│   │   ├── GameDAO.java                   ← getAllGames / searchGames / getGameById / purchaseGame / addReview
│   │   └── UserDAO.java                   ← register / login / isDuplicateId / getUserBySid / updateUser / deleteUser / getAllUsers
│   ├── main/
│   │   └── MainSystem.java                ← 콘솔 테스트용 (서블릿과 무관, main() 직접 실행 전용)
│   └── model/                             ← 데이터 객체 (VO)
│       ├── Game.java
│       └── User.java
└── src/main/webapp/                       ← 웹 루트 (정적 파일 + JSP)
    ├── WEB-INF/
    │   ├── lib/                           ← 서버에 배포되는 jar 파일
    │   │   ├── ojdbc11.jar                 (Oracle JDBC 드라이버)
    │   │   ├── jakarta.servlet.jsp.jstl-3.0.1.jar     (JSTL 구현체)
    │   │   └── jakarta.servlet.jsp.jstl-api-3.0.2.jar (JSTL API)
    │   └── web.xml                        ← 배포 설정 (서블릿 매핑은 안 씀 — 전부 @WebServlet 어노테이션 사용)
    ├── resources/
    │   ├── css/
    │   │   └── mdgs.css                   ← 전체 사이트 스타일시트
    │   ├── images/                        ← 게임 표지 이미지 + 로고 등 (홈 배너 슬라이드에도 재사용)
    │   │   ├── MDGS_Logo.png
    │   │   ├── MDGS_Theme.png
    │   │   ├── HADES_4k.jpg
    │   │   ├── R6_4k.jpg
    │   │   ├── Clair_Obscur_Expedition_33_4k.jpg
    │   │   └── DIAVLO_IV_4k.png
    │   └── newFile.js                     ← 호버 프리뷰 / 배너 슬라이드 / 회원탈퇴 확인창 스크립트
    └── views/                             ← 화면(JSP)
        ├── common/
        │   ├── header.jsp                 ← 상단 배너+검색창+네비게이션 (모든 페이지 공통 포함)
        │   └── footer.jsp                 ← 하단 푸터 (모든 페이지 공통 포함)
        ├── gameList.jsp                   ← 게임 목록/검색 결과 화면 (홈 화면 겸용) + 배너 슬라이드
        ├── gameDetail.jsp                 ← 게임 상세 화면
        ├── login.jsp                      ← 로그인 폼
        ├── register.jsp                   ← 회원가입 폼
        ├── mypage.jsp                     ← 마이페이지
        └── support.jsp                    ← 고객지원
```

---

## 2. HTML / CSS / 이미지 / JS는 어디에 있는가

이 프로젝트에는 순수 HTML 파일이 없습니다. 원래 정적 프로토타입이었던 `MDGS.html`/`MDGS.css`(별도 프로젝트 `3_Front/subject`에 존재)를 이 프로젝트로 옮기면서 전부 **JSP**로 전환했습니다.

| 종류 | 위치 | 비고 |
|---|---|---|
| 화면(옛 HTML) | `src/main/webapp/views/*.jsp` | 서블릿이 `forward`로만 진입 가능 (직접 URL 접근 대신 `/`, `/login`, `/mypage` 등 경유) |
| 공통 헤더/푸터 | `src/main/webapp/views/common/*.jsp` | `<jsp:include>`로 각 화면에 삽입됨 |
| CSS | `src/main/webapp/resources/css/mdgs.css` | 다크 테마, `:root`에 색상 변수 정의 |
| 이미지 | `src/main/webapp/resources/images/` | 게임 표지 6장 (파일명 공백은 전부 `_`로 치환됨) |
| JS | `src/main/webapp/resources/newFile.js` | 호버 프리뷰 / 배너 자동·수동 슬라이드 / 회원탈퇴 확인창 (바닐라 JS, 파일 하나) |

JSP에서는 전부 `${ctx}/resources/...` 형태로 참조합니다 (`${ctx}`는 `${pageContext.request.contextPath}`의 줄임 — 각 JSP 상단 `<c:set var="ctx" .../>`로 선언).

---

## 3. Java 소스 — 패키지별 역할

| 패키지 | 클래스 | 역할 |
|---|---|---|
| `config` | `DBConnection` | `DriverManager`로 Oracle 접속 (커넥션 풀 없이 매번 새 연결). URL/계정 정보 하드코딩 |
| `controller` | `GameListServlet` | `""`(홈)과 `/GameListServlet` 두 경로 처리. `q` 파라미터가 있으면 검색, 없으면 전체 조회 후 `gameList.jsp`로 forward |
| `controller` | `GameDetailServlet` | `/gameDetail?id=N`. 게임 하나를 조회해 `gameDetail.jsp`로 forward |
| `controller` | `LoginServlet` | `/login`. GET은 폼 표시, POST는 `UserDAO.login()` 검증 후 세션 생성 |
| `controller` | `LogoutServlet` | `/logout`. 세션 무효화 후 홈으로 redirect |
| `controller` | `RegisterServlet` | `/register`. GET은 폼 표시, POST는 중복 ID 체크 후 `UserDAO.register()` |
| `controller` | `MyPageServlet` | `/mypage`. 로그인 필요. 계정 정보 수정 / 회원 탈퇴(관리자 계정은 서버에서 차단) 처리 |
| `controller` | `SupportServlet` | `/support`. 로그인 상태·관리자 여부에 따라 다른 내용을 담아 `support.jsp`로 forward |
| `dao` | `UserDAO` | `USERS` 테이블 CRUD: `register`, `login`, `isDuplicateId`, `getUserBySid`, `updateUser`, `deleteUser`, `getAllUsers`(관리자용) |
| `dao` | `GameDAO` | `getAllGames`, `searchGames`(제목 부분 검색), `getGameById` 사용 중. `purchaseGame`/`addReview`는 작성만 되어 있고 어떤 서블릿도 아직 호출하지 않음 (구매/리뷰 미구현) |
| `model` | `User` | `USERS` 테이블 한 행에 대응하는 VO |
| `model` | `Game` | `GAMES` 테이블 한 행에 대응하는 VO (`imagePath` 포함) |
| `main` | `MainSystem` | Tomcat/서블릿과 무관한 콘솔 테스트 클래스. `main()`을 직접 실행해서 DAO 동작을 확인할 때만 사용 |

> `service` 패키지(빈 `UserService`/`GameService`)는 사용하지 않기로 결정하여 현재 프로젝트에 존재하지 않습니다. 서블릿이 DAO를 직접 호출하는 구조입니다.

---

## 4. URL 라우팅 표

| URL | 메서드 | 처리 서블릿 | 동작 |
|---|---|---|---|
| `/` | GET | `GameListServlet` | `q` 파라미터 없으면 전체 게임 목록, 있으면 검색 결과 → `gameList.jsp` |
| `/GameListServlet` | GET | `GameListServlet` | 위와 동일 (기존 경로 유지) |
| `/gameDetail?id=N` | GET | `GameDetailServlet` | 게임 하나 조회 → `gameDetail.jsp` |
| `/login` | GET | `LoginServlet` | `login.jsp` 표시 |
| `/login` | POST | `LoginServlet` | 로그인 검증 → 성공 시 세션 생성 후 `/`로 이동, 실패 시 에러 메시지와 함께 `login.jsp` 재표시 |
| `/logout` | GET/POST | `LogoutServlet` | 세션 종료 후 `/`로 이동 |
| `/register` | GET | `RegisterServlet` | `register.jsp` 표시 |
| `/register` | POST | `RegisterServlet` | 중복 ID 체크 → 가입 처리 → 성공 시 `/login`으로 이동 |
| `/mypage` | GET | `MyPageServlet` | 로그인 필요(없으면 `/login`으로 리다이렉트) → `mypage.jsp` |
| `/mypage` | POST | `MyPageServlet` | 숨김 필드 `action`이 `withdraw`면 탈퇴, 아니면 계정 정보 수정 |
| `/support` | GET/POST | `SupportServlet` | 로그인 불필요. 관리자 로그인 시 전체 회원 목록도 함께 조회 → `support.jsp` |

**세션/요청 속성 이름 규칙**
- 세션: `loginId` (로그인한 아이디 문자열), `userSid` (User_SID, DB 조회/수정/삭제 시 사용)
- 요청: `errorMsg`/`successMsg` (처리 결과 메시지), `gameList` (`List<Game>`), `game` (`Game`, 상세 페이지용), `user` (`User`, 마이페이지용), `isAdmin` (boolean), `allUsers` (`List<User>`, 관리자 전용)

헤더(`views/common/header.jsp`)는 `sessionScope.loginId` 유무로 장바구니 노출 여부와 "로그인/회원가입" ↔ "{아이디}님 · 내 페이지" 표시를 전환합니다 (로그아웃 버튼은 헤더가 아니라 마이페이지 안에 있음). 관리자 판별은 `SupportServlet`/`MyPageServlet`에 각각 있는 `ADMIN_ID = "MDGS1226"` 상수와 `loginId`를 비교하는 방식입니다 — 자세한 동작은 [FEATURES_GUIDE.md](FEATURES_GUIDE.md) 참고.

---

## 5. 데이터베이스 스키마

Oracle, 계정 `C##MDGS` (SID: `xe`). 실제 스크립트는 `sql/schema.sql` 참고.

**USERS**
| 컬럼 | 타입 | 비고 |
|---|---|---|
| User_SID | VARCHAR2(30) | PK |
| ID | VARCHAR2(50) | UNIQUE, 로그인 아이디 |
| Password | VARCHAR2(100) | 평문 저장 (해싱 미적용) |
| Email | VARCHAR2(100) | |
| Age | NUMBER(3) | |
| Address | VARCHAR2(200) | |
| Card_Num | VARCHAR2(30) | |

관리자 계정 하나(`ID = MDGS1226`)가 DB에 직접 미리 생성되어 있습니다. 일반 회원가입 절차를 거치지 않고 만들어졌고, 이 `ID` 문자열 자체가 곧 "관리자 여부"를 가르는 값입니다 (자세한 동작은 [FEATURES_GUIDE.md](FEATURES_GUIDE.md)의 11번 항목 참고).

**GAMES**
| 컬럼 | 타입 | 비고 |
|---|---|---|
| GAME_ID | NUMBER | PK |
| TITLE | VARCHAR2(200) | 검색 대상 컬럼 (`LIKE '%키워드%'`) |
| GENRE | VARCHAR2(50) | 목록 화면 카테고리 표시에 사용 |
| PRICE | NUMBER(10,2) | 상세 페이지에서 통화 형식으로 표시 |
| RELEASE_DATE | DATE | 상세 페이지에서 `yyyy-MM-dd` 형식으로 표시 |
| DEVELOPER | VARCHAR2(100) | |
| IMAGE_PATH | VARCHAR2(200) | `resources/images/...` 형태 상대 경로. 목록/배너/상세 페이지가 모두 이 컬럼을 사용 |

현재 시드 데이터: Hades / Rainbow Six Siege / Clair Obscur: Expedition 33 / Diablo IV (Game_ID 1~4).

**그 외 (존재하지만 미사용)**: `TRANSACTIONS`, `USER_LIBRARY`, `REVIEWS` 테이블이 이미 생성되어 있고 `GAMES`를 외래 키로 참조합니다. `GameDAO.purchaseGame()` / `addReview()`가 이 테이블들을 다루도록 작성되어는 있지만, 구매·리뷰 기능 자체가 아직 화면/서블릿에 연결되지 않아 실제로는 사용되지 않는 상태입니다.

---

## 6. 정적 프로토타입과의 관계

이 프로젝트가 시작되기 전 `c:\workspace\3_Front\subject\MDGS.html` / `MDGS.css`로 만들어졌던 정적 시안이 있습니다. 그 파일들의 디자인(다크 테마, 배너, 카테고리 메뉴, 게임 카드 그리드, 우측 프리뷰 패널)을 그대로 가져와 JSP로 재구성한 것이 `views/gameList.jsp` + `resources/css/mdgs.css`의 출발점입니다. 원본과 다른 점:
- 게임 카드가 하드코딩이 아니라 `<c:forEach>`로 DB 데이터를 순회하며 렌더링됨 (검색 결과도 같은 방식)
- 카드 hover 시 우측 프리뷰 이미지를 바꾸던 CSS(`nth-child` 기반)는 게임 개수에 따라 깨지므로 제거하고, 자바스크립트(`newFile.js`)로 대체
- 원본에 없던 화면(로그인/회원가입, 게임 상세, 마이페이지, 고객지원)과 기능(배너 자동 슬라이드, 검색)을 이후 작업에서 새로 추가

---

## 7. 구현 범위

**완료**: 로그인, 회원가입(중복 ID 체크 포함), 로그아웃, 게임 목록 열람(DB 연동), 게임 검색(제목 부분 일치), 게임 상세 페이지, 메인 배너 자동/수동 슬라이드, 게임 카드 호버 프리뷰, 로그인 상태에 따른 헤더 표시 전환, 마이페이지(계정 정보 수정 실반영, 회원 탈퇴 실반영·관리자 계정 제외, 장바구니/결제는 화면용 목업), 고객지원 페이지(정적 FAQ + 로그인 상태별 안내 + 관리자 전용 전체 회원 조회)

**미구현 (의도적으로 범위 제외)**: 실제 게임 구매/결제, 리뷰 작성, Service 계층
