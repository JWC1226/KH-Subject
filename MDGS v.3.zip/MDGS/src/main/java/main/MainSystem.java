package main;

import dao.GameDAO;
import dao.UserDAO;
import model.Game;
import model.User;

import java.util.List;

public class MainSystem {
    public static void main(String[] args) {
        // 1. [SQL Developer 대체] DB 스키마 자동 초기화
        UserDAO userDAO = new UserDAO();
        GameDAO gameDAO = new GameDAO();

        // 회원가입 실행
        System.out.println("\n--- [1] 회원가입 진행 ---");
        String userSid = "U_20260801_001";
        User newUser = new User(userSid, "dev_gamer", "pass1234", "gamer@domain.com", 26, "Seoul, Korea", "1234-5678-9012-3456");
        
        if (userDAO.register(newUser)) {
            System.out.println("회원 가입 성공! 계정: " + newUser.getId());
        }

        // 로그인 테스트
        System.out.println("\n--- [2] 로그인 시도 ---");
        String loggedInSid = userDAO.login("dev_gamer", "pass1234");
        
        if (loggedInSid != null) {
            System.out.println("로그인 성공! 로그인한 회원 SID: " + loggedInSid);

            // 스토어 내 게임 카탈로그 목록 출력
            System.out.println("\n--- [3] 게임 스토어 목록 조회 ---");
            List<Game> storeGames = gameDAO.getAllGames();
            for (Game g : storeGames) {
                System.out.println(g);
            }

            // 게임 구매 (Cyberpunk 2077 - Game_ID: 2)
            System.out.println("\n--- [4] 게임 구매 처리 ---");
            boolean purchaseSuccess = gameDAO.purchaseGame(loggedInSid, 2, 59.99, "Credit Card");
            if (purchaseSuccess) {
                System.out.println("게임 결제 완료! 'Cyberpunk 2077'이 사용자 라이브러리에 등록되었습니다.");
            }

            // 구매한 게임에 대한 리뷰 등록
            System.out.println("\n--- [5] 게임 리뷰 작성 ---");
            boolean reviewSuccess = gameDAO.addReview(
                loggedInSid, 
                2, 
                5.0, 
                "그래픽과 몰입감이 최고입니다. 최적화 모드를 적용해 플레이하니 성능 저하 없이 정말 쾌적하게 즐길 수 있습니다!"
            );
            
            if (reviewSuccess) {
                System.out.println("리뷰가 정상적으로 스토어에 등록되었습니다.");
            }

        } else {
            System.out.println("로그인 실패: 아이디나 비밀번호를 확인하세요.");
        }
    }
}