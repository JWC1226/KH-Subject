-- USERS는 신규 생성
CREATE TABLE USERS (
    User_SID   VARCHAR2(30)  PRIMARY KEY,
    ID         VARCHAR2(50)  UNIQUE NOT NULL,
    Password   VARCHAR2(100) NOT NULL,
    Email      VARCHAR2(100),
    Age        NUMBER(3),
    Address    VARCHAR2(200),
    Card_Num   VARCHAR2(30)
);

-- 현재 관리자 계정: 일반 회원가입(RegisterServlet)을 거치지 않고 DB에 직접 만드는 계정.
-- ID 값 'MDGS1226' 자체가 곧 "관리자 여부" 판단 기준이므로 여기 값을 바꾸면 그 두 서블릿의 상수도 같이 바꿔야 한다
-- 이미 실행된 상태라면 UNIQUE 제약조건 위반이 발생하지만, 무시 가능
INSERT INTO USERS (User_SID, ID, Password, Email, Age, Address, Card_Num)
VALUES ('U_ADMIN', 'MDGS1226', 'admin1226', 'admin@mdgs.com', 30, '서울', NULL);
COMMIT;


ALTER TABLE GAMES ADD (IMAGE_PATH VARCHAR2(200));
DELETE FROM GAMES;
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (1, 'Hades', '액션 로그라이크', 24.99, DATE '2020-09-17', 'Supergiant Games', 'resources/images/HADES_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (2, 'Rainbow Six Siege', 'FPS', 19.99, DATE '2015-12-01', 'Ubisoft', 'resources/images/R6_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (3, 'Clair Obscur: Expedition 33', '풍부한 스토리', 49.99, DATE '2025-04-24', 'Sandfall Interactive', 'resources/images/Clair_Obscur_Expedition_33_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (4, 'Diablo IV', '핵 앤 슬래시', 39.99, DATE '2023-06-06', 'Blizzard Entertainment', 'resources/images/DIAVLO_IV_4k.png');
COMMIT;