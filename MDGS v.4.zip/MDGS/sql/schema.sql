-- USERS는 신규 생성 (이미 실행 완료된 상태라면 ORA-00955는 무시해도 됨)
CREATE TABLE USERS (
    User_SID   VARCHAR2(30)  PRIMARY KEY,
    ID         VARCHAR2(50)  UNIQUE NOT NULL,
    Password   VARCHAR2(100) NOT NULL,
    Email      VARCHAR2(100),
    Age        NUMBER(3),
    Address    VARCHAR2(200),
    Card_Num   VARCHAR2(30)
);

-- GAMES는 이전 MainSystem.java 테스트 때 이미 만들어져 있던 테이블(6개 컬럼, IMAGE_PATH 없음)이라
-- CREATE TABLE 대신 ALTER TABLE로 컬럼만 추가한다. TRANSACTIONS/USER_LIBRARY/REVIEWS가 GAMES를
-- 외래 키로 참조하고 있어 DROP TABLE은 ORA-02449로 실패함
-- DELETE는 안전
ALTER TABLE GAMES ADD (IMAGE_PATH VARCHAR2(200));

DELETE FROM GAMES;

INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (1, 'Hades', '액션 로그라이크', 24.99, DATE '2020-09-17', 'Supergiant Games', 'resources/images/HADES_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (2, 'Rainbow Six Siege', 'FPS', 19.99, DATE '2015-12-01', 'Ubisoft', 'resources/images/R6_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (3, 'Clair Obscur: Expedition 33', '풍부한 스토리', 49.99, DATE '2025-04-24', 'Sandfall Interactive', 'resources/images/Clair_Obscur_Expedition_33_4k.jpg');
INSERT INTO GAMES (GAME_ID, TITLE, GENRE, PRICE, RELEASE_DATE, DEVELOPER, IMAGE_PATH)
VALUES (4, 'Diablo IV', '핵 앤 슬래시', 39.99, DATE '2023-06-06', 'Blizzard Entertainment', 'resources/images/DIAVLO_IV_4k.png');

COMMIT;
