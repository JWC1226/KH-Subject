package model;

public class User {
    private String userSid;
    private String id;
    private String password;
    private String email;
    private int age;
    private String address;
    private String cardNum;

    public User(String userSid, String id, String password, String email, int age, String address, String cardNum) {
        this.userSid = userSid;
        this.id = id;
        this.password = password;
        this.email = email;
        this.age = age;
        this.address = address;
        this.cardNum = cardNum;
    }

    public String getUserSid() { return userSid; }
    public String getId() { return id; }
    public String getPassword() { return password; }
    public String getEmail() { return email; }
    public int getAge() { return age; }
    public String getAddress() { return address; }
    public String getCardNum() { return cardNum; }
}