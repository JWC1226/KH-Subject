package controller;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/support")
public class SupportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String ADMIN_ID = "MDGS1226";
	private UserDAO userDAO = new UserDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		String loginId = (session != null) ? (String) session.getAttribute("loginId") : null;
		boolean isAdmin = ADMIN_ID.equals(loginId);

		req.setAttribute("isAdmin", isAdmin);
		if (isAdmin) {
			req.setAttribute("allUsers", userDAO.getAllUsers());
		}
		req.getRequestDispatcher("/views/support.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
