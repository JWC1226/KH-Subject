package controller;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;

@WebServlet("/mypage")
public class MyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String ADMIN_ID = "MDGS1226";
	private UserDAO userDAO = new UserDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		if (session == null || session.getAttribute("userSid") == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		String userSid = (String) session.getAttribute("userSid");
		User user = userDAO.getUserBySid(userSid);
		req.setAttribute("user", user);
		req.setAttribute("isAdmin", ADMIN_ID.equals(session.getAttribute("loginId")));
		req.getRequestDispatcher("/views/mypage.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		if (session == null || session.getAttribute("userSid") == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		String userSid = (String) session.getAttribute("userSid");
		String action = req.getParameter("action");
		boolean isAdmin = ADMIN_ID.equals(session.getAttribute("loginId"));

		if ("withdraw".equals(action)) {
			if (isAdmin) {
				req.setAttribute("errorMsg", "관리자 계정은 탈퇴할 수 없습니다.");
				req.setAttribute("user", userDAO.getUserBySid(userSid));
				req.setAttribute("isAdmin", true);
				req.getRequestDispatcher("/views/mypage.jsp").forward(req, resp);
				return;
			}
			if (userDAO.deleteUser(userSid)) {
				session.invalidate();
				resp.sendRedirect(req.getContextPath() + "/");
			} else {
				req.setAttribute("errorMsg", "회원 탈퇴에 실패했습니다. 잠시 후 다시 시도해주세요.");
				req.setAttribute("user", userDAO.getUserBySid(userSid));
				req.setAttribute("isAdmin", isAdmin);
				req.getRequestDispatcher("/views/mypage.jsp").forward(req, resp);
			}
			return;
		}

		String email = req.getParameter("email");
		int age = Integer.parseInt(req.getParameter("age"));
		String address = req.getParameter("address");
		String cardNum = req.getParameter("cardNum");

		boolean success = userDAO.updateUser(userSid, email, age, address, cardNum);
		if (success) {
			req.setAttribute("successMsg", "계정 정보가 저장되었습니다.");
		} else {
			req.setAttribute("errorMsg", "정보 저장에 실패했습니다. 잠시 후 다시 시도해주세요.");
		}
		req.setAttribute("user", userDAO.getUserBySid(userSid));
		req.setAttribute("isAdmin", isAdmin);
		req.getRequestDispatcher("/views/mypage.jsp").forward(req, resp);
	}
}
