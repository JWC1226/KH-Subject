package controller;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		String userSid = userDAO.login(id, password);

		if (userSid != null) {
			HttpSession session = req.getSession();
			session.setAttribute("userSid", userSid);
			session.setAttribute("loginId", id);
			resp.sendRedirect(req.getContextPath() + "/");
		} else {
			req.setAttribute("errorMsg", "아이디 또는 비밀번호가 올바르지 않습니다.");
			req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
		}
	}
}
