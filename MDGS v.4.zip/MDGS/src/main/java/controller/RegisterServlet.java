package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String id = req.getParameter("id");

		if (userDAO.isDuplicateId(id)) {
			req.setAttribute("errorMsg", "중복된 ID입니다.");
			req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
			return;
		}

		User newUser = new User(
			generateUserSid(), id,
			req.getParameter("password"),
			req.getParameter("email"),
			Integer.parseInt(req.getParameter("age")),
			req.getParameter("address"),
			req.getParameter("cardNum")
		);

		if (userDAO.register(newUser)) {
			resp.sendRedirect(req.getContextPath() + "/login");
		} else {
			req.setAttribute("errorMsg", "회원가입에 실패했습니다. 잠시 후 다시 시도해주세요.");
			req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
		}
	}

	private String generateUserSid() {
		return "U_" + new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
}
