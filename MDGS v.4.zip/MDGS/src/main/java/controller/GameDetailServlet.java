package controller;

import java.io.IOException;

import dao.GameDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Game;

@WebServlet("/gameDetail")
public class GameDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private GameDAO gameDAO = new GameDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Game game = null;
		try {
			int gameId = Integer.parseInt(req.getParameter("id"));
			game = gameDAO.getGameById(gameId);
		} catch (NumberFormatException e) {
			game = null;
		}
		req.setAttribute("game", game);
		req.getRequestDispatcher("/views/gameDetail.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
