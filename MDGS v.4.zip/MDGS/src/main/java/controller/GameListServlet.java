package controller;

import java.io.IOException;
import java.util.List;

import dao.GameDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Game;

@WebServlet("")
public class GameListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private GameDAO gameDAO = new GameDAO();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String keyword = req.getParameter("q");
		List<Game> gameList;
		if (keyword != null && !keyword.trim().isEmpty()) {
			gameList = gameDAO.searchGames(keyword.trim());
		} else {
			gameList = gameDAO.getAllGames();
		}
		req.setAttribute("gameList", gameList);
		req.getRequestDispatcher("/views/gameList.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}