package dao;

import config.DBConnection;
import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // 회원가입
    public boolean register(User user) {
        String sql = "INSERT INTO USERS (User_SID, ID, Password, Email, Age, Address, Card_Num) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUserSid());
            pstmt.setString(2, user.getId());
            pstmt.setString(3, user.getPassword());
            pstmt.setString(4, user.getEmail());
            pstmt.setInt(5, user.getAge());
            pstmt.setString(6, user.getAddress());
            pstmt.setString(7, user.getCardNum());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("회원가입 실패: " + e.getMessage());
            return false;
        }
    }

    // 로그인 (성공 시 User_SID 반환, 실패 시 null)
    public String login(String id, String password) {
        String sql = "SELECT User_SID FROM USERS WHERE ID = ? AND Password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("User_SID");
                }
            }
        } catch (SQLException e) {
            System.err.println("로그인 연동 오류: " + e.getMessage());
        }
        return null;
    }
    
    // 첫 번째 미니 프로젝트를 살려서 활용
    public boolean isDuplicateId(String id) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE ID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("중복 확인 오류: " + e.getMessage());
        }
        return false;
    }

    // User_SID로 단일 회원 조회 (마이페이지용)
    public User getUserBySid(String userSid) {
        String sql = "SELECT * FROM USERS WHERE User_SID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userSid);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                        rs.getString("User_SID"),
                        rs.getString("ID"),
                        rs.getString("Password"),
                        rs.getString("Email"),
                        rs.getInt("Age"),
                        rs.getString("Address"),
                        rs.getString("Card_Num")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("회원 조회 오류: " + e.getMessage());
        }
        return null;
    }

    // 계정 정보 수정 (이메일/나이/주소/카드번호만; ID/비밀번호는 이 화면 범위 밖)
    public boolean updateUser(String userSid, String email, int age, String address, String cardNum) {
        String sql = "UPDATE USERS SET Email = ?, Age = ?, Address = ?, Card_Num = ? WHERE User_SID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            pstmt.setInt(2, age);
            pstmt.setString(3, address);
            pstmt.setString(4, cardNum);
            pstmt.setString(5, userSid);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("계정 정보 수정 오류: " + e.getMessage());
            return false;
        }
    }

    // 회원 탈퇴 (USERS 행 삭제)
    public boolean deleteUser(String userSid) {
        String sql = "DELETE FROM USERS WHERE User_SID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userSid);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("회원 탈퇴 오류: " + e.getMessage());
            return false;
        }
    }

    // 전체 회원 조회 (관리자용)
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM USERS ORDER BY User_SID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(new User(
                    rs.getString("User_SID"),
                    rs.getString("ID"),
                    rs.getString("Password"),
                    rs.getString("Email"),
                    rs.getInt("Age"),
                    rs.getString("Address"),
                    rs.getString("Card_Num")
                ));
            }
        } catch (SQLException e) {
            System.err.println("전체 회원 조회 오류: " + e.getMessage());
        }
        return list;
    }
}