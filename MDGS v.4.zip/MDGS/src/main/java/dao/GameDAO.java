package dao;

import config.DBConnection;
import model.Game;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GameDAO {

    // 1. 스토어 전체 게임 조회
    public List<Game> getAllGames() {
        List<Game> list = new ArrayList<>();
        String sql = "SELECT * FROM GAMES";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Game(
                    rs.getInt("Game_ID"),
                    rs.getString("Title"),
                    rs.getString("Genre"),
                    rs.getDouble("Price"),
                    rs.getDate("Release_Date"),
                    rs.getString("Developer"),
                    rs.getString("Image_Path")
                ));
            }
        } catch (SQLException e) {
            System.err.println("게임 조회 오류: " + e.getMessage());
        }
        return list;
    }

    // 1-1. 제목 검색 (부분 일치)
    public List<Game> searchGames(String keyword) {
        List<Game> list = new ArrayList<>();
        String sql = "SELECT * FROM GAMES WHERE UPPER(Title) LIKE UPPER(?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, "%" + keyword + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new Game(
                        rs.getInt("Game_ID"),
                        rs.getString("Title"),
                        rs.getString("Genre"),
                        rs.getDouble("Price"),
                        rs.getDate("Release_Date"),
                        rs.getString("Developer"),
                        rs.getString("Image_Path")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("게임 검색 오류: " + e.getMessage());
        }
        return list;
    }

    // 1-2. 단일 게임 상세 조회
    public Game getGameById(int gameId) {
        String sql = "SELECT * FROM GAMES WHERE Game_ID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gameId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Game(
                        rs.getInt("Game_ID"),
                        rs.getString("Title"),
                        rs.getString("Genre"),
                        rs.getDouble("Price"),
                        rs.getDate("Release_Date"),
                        rs.getString("Developer"),
                        rs.getString("Image_Path")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("게임 상세 조회 오류: " + e.getMessage());
        }
        return null;
    }
}