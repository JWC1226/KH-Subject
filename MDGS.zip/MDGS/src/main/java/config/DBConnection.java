package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // ojdbc11 드라이버 클래스명
    private static final String DRIVER = "oracle.jdbc.OracleDriver";
    
    // 본인의 Oracle 접속 정보로 수정 (Local, XE 버전 예시)
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; // 또는 :orcl, @localhost:1521/XEPDB1
    private static final String USER = "SYSTEM"; // DB 사용자명
    private static final String PASS = "oracle"; // DB 비밀번호

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("ojdbc11 드라이버를 찾을 수 없습니다. Build Path를 확인해 주세요: " + e.getMessage());
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}