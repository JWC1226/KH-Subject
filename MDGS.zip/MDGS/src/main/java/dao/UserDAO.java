package dao;

import config.DBConnection;
import model.User;
import java.sql.*;

public class UserDAO {

    // 회원가입
    public boolean register(User user) {
        String sql = "INSERT INTO USERS (User_SID, ID, Password, Email, Age, Address, Card_Num) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUserSid());
            pstmt.setString(2, user.getId());
            pstmt.setString(3, user.getPassword());
            pstmt.setString(4, user.getEmail());
            pstmt.setInt(5, user.getAge());
            pstmt.setString(6, user.getAddress());
            pstmt.setString(7, user.getCardNum());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("회원가입 실패: " + e.getMessage());
            return false;
        }
    }

    // 로그인 (성공 시 User_SID 반환, 실패 시 null)
    public String login(String id, String password) {
        String sql = "SELECT User_SID FROM USERS WHERE ID = ? AND Password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("User_SID");
                }
            }
        } catch (SQLException e) {
            System.err.println("로그인 연동 오류: " + e.getMessage());
        }
        return null;
    }
}