-- ==============================================================================
-- Game Store Database Initialization Script (Oracle SQL)
-- Description: Creates the core tables for a Steam-like game platform.
-- ==============================================================================

-- 1. DROP EXISTING TABLES (Optional, for clean initialization)
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE REVIEWS CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE TRANSACTIONS CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE USER_LIBRARY CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE GAMES CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE USERS CASCADE CONSTRAINTS';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;
/

-- ==============================================================================
-- 2. CREATE TABLES
-- ==============================================================================

-- USERS (회원)
CREATE TABLE USERS (
    User_SID VARCHAR2(100) PRIMARY KEY,
    ID VARCHAR2(100) NOT NULL UNIQUE,
    Password VARCHAR2(250) NOT NULL,
    Email VARCHAR2(100) UNIQUE,
    Age NUMBER NOT NULL,
    Address VARCHAR2(500),
    Card_Num VARCHAR2(100)
);

-- GAMES (게임 카탈로그)
CREATE TABLE GAMES (
    Game_ID NUMBER PRIMARY KEY,
    Title VARCHAR2(200) NOT NULL,
    Genre VARCHAR2(100),
    Price NUMBER(10,2) NOT NULL,
    Release_Date DATE,
    Developer VARCHAR2(150)
);

-- USER_LIBRARY (사용자 라이브러리)
CREATE TABLE USER_LIBRARY (
    Library_ID NUMBER PRIMARY KEY,
    User_SID VARCHAR2(100) NOT NULL,
    Game_ID NUMBER NOT NULL,
    Purchase_Date DATE DEFAULT SYSDATE,
    Playtime_Hours NUMBER DEFAULT 0,
    CONSTRAINT fk_lib_user FOREIGN KEY (User_SID) REFERENCES USERS(User_SID),
    CONSTRAINT fk_lib_game FOREIGN KEY (Game_ID) REFERENCES GAMES(Game_ID)
);

-- TRANSACTIONS (결제 내역)
CREATE TABLE TRANSACTIONS (
    Tx_ID NUMBER PRIMARY KEY,
    User_SID VARCHAR2(100) NOT NULL,
    Total_Amount NUMBER(10,2) NOT NULL,
    Payment_Method VARCHAR2(50),
    Tx_Date DATE DEFAULT SYSDATE,
    CONSTRAINT fk_tx_user FOREIGN KEY (User_SID) REFERENCES USERS(User_SID)
);

-- REVIEWS (게임 리뷰)
CREATE TABLE REVIEWS (
    Review_ID NUMBER PRIMARY KEY,
    User_SID VARCHAR2(100) NOT NULL,
    Game_ID NUMBER NOT NULL,
    Rating NUMBER(2,1) CHECK (Rating >= 0 AND Rating <= 5),
    Review_Text CLOB,
    Review_Date DATE DEFAULT SYSDATE,
    CONSTRAINT fk_rev_user FOREIGN KEY (User_SID) REFERENCES USERS(User_SID),
    CONSTRAINT fk_rev_game FOREIGN KEY (Game_ID) REFERENCES GAMES(Game_ID)
);

-- ==============================================================================
-- 3. INSERT SAMPLE DATA
-- ==============================================================================

-- Sample Games Insert
INSERT INTO GAMES (Game_ID, Title, Genre, Price, Release_Date, Developer) 
VALUES (1, 'Death Stranding 2: On the Beach', 'Action/Adventure', 69.99, TO_DATE('2025-10-01', 'YYYY-MM-DD'), 'Kojima Productions');

INSERT INTO GAMES (Game_ID, Title, Genre, Price, Release_Date, Developer) 
VALUES (2, 'Cyberpunk 2077', 'RPG/Cyberpunk', 59.99, TO_DATE('2020-12-10', 'YYYY-MM-DD'), 'CD Projekt Red');

INSERT INTO GAMES (Game_ID, Title, Genre, Price, Release_Date, Developer) 
VALUES (3, 'VRChat', 'Social/VR', 0.00, TO_DATE('2017-02-01', 'YYYY-MM-DD'), 'VRChat Inc.');

-- Sample User Insert
INSERT INTO USERS (User_SID, ID, Password, Email, Age, Address, Card_Num) 
VALUES ('U_20260801_001', 'dev_gamer', 'hashed_pw_abc123', 'dev_gamer@example.com', 26, 'Seoul, South Korea', '1234-5678-9012-3456');

-- Sample Library Insert
INSERT INTO USER_LIBRARY (Library_ID, User_SID, Game_ID, Purchase_Date, Playtime_Hours) 
VALUES (101, 'U_20260801_001', 2, TO_DATE('2026-05-15', 'YYYY-MM-DD'), 145);

INSERT INTO USER_LIBRARY (Library_ID, User_SID, Game_ID, Purchase_Date, Playtime_Hours) 
VALUES (102, 'U_20260801_001', 1, TO_DATE('2026-06-20', 'YYYY-MM-DD'), 30);

-- Sample Transactions Insert
INSERT INTO TRANSACTIONS (Tx_ID, User_SID, Total_Amount, Payment_Method, Tx_Date)
VALUES (10001, 'U_20260801_001', 129.98, 'Credit Card', TO_DATE('2026-05-15', 'YYYY-MM-DD'));

-- Sample Reviews Insert
INSERT INTO REVIEWS (Review_ID, User_SID, Game_ID, Rating, Review_Text, Review_Date) 
VALUES (501, 'U_20260801_001', 2, 5.0, 'Incredible world design. I highly recommend running this with performance-optimized mods to truly enhance the immersion. Runs flawlessly on my RTX 3070 laptop without overloading the hardware!', TO_DATE('2026-07-10', 'YYYY-MM-DD'));

INSERT INTO REVIEWS (Review_ID, User_SID, Game_ID, Rating, Review_Text, Review_Date) 
VALUES (502, 'U_20260801_001', 1, 4.5, 'The narrative structure is captivating, and the updated first-person aiming mechanics feel incredibly tight and responsive.', TO_DATE('2026-07-25', 'YYYY-MM-DD'));

COMMIT;
