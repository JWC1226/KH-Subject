package config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * DB 커넥션 관리 클래스.
 * 접속 정보(URL/USER/PASS)는 소스코드에 하드코딩하지 않고
 * classpath 상의 db.properties 파일에서 읽어온다.
 * (Eclipse에서 resources 폴더를 소스 폴더로 추가해야 classpath에 포함됨)
 */
public class DBConnection {

    private static final String DRIVER = "oracle.jdbc.OracleDriver";
    private static final Properties props = new Properties();

    static {
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in == null) {
                throw new IOException("db.properties 파일을 classpath 에서 찾을 수 없습니다. " +
                        "(resources 폴더가 Build Path 의 Source Folder 로 등록되어 있는지 확인하세요.)");
            }
            props.load(in);
        } catch (IOException e) {
            System.err.println("DB 설정 파일 로드 실패: " + e.getMessage());
        }

        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("ojdbc11 드라이버를 찾을 수 없습니다. Build Path(ojdbc11-23.26.2.0.0.jar)를 확인해 주세요: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        String url = props.getProperty("db.url");
        String user = props.getProperty("db.user");
        String pass = props.getProperty("db.password");
        return DriverManager.getConnection(url, user, pass);
    }
}
