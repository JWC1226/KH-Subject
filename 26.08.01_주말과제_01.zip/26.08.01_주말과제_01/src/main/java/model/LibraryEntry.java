package model;

import java.sql.Date;

public class LibraryEntry {
    private int libraryId;
    private int gameId;
    private String gameTitle;
    private Date purchaseDate;
    private int playtimeHours;

    public LibraryEntry(int libraryId, int gameId, String gameTitle, Date purchaseDate, int playtimeHours) {
        this.libraryId = libraryId;
        this.gameId = gameId;
        this.gameTitle = gameTitle;
        this.purchaseDate = purchaseDate;
        this.playtimeHours = playtimeHours;
    }

    public int getLibraryId() { return libraryId; }
    public int getGameId() { return gameId; }
    public String getGameTitle() { return gameTitle; }
    public Date getPurchaseDate() { return purchaseDate; }
    public int getPlaytimeHours() { return playtimeHours; }

    @Override
    public String toString() {
        return String.format("[보유] %s (구매일: %s, 누적 플레이: %d시간)", gameTitle, purchaseDate, playtimeHours);
    }
}
