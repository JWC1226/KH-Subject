package model;

import java.sql.Date;

public class Review {
    private long reviewId;
    private String userSid;
    private int gameId;
    private double rating;
    private String reviewText;
    private Date reviewDate;

    public Review(long reviewId, String userSid, int gameId, double rating, String reviewText, Date reviewDate) {
        this.reviewId = reviewId;
        this.userSid = userSid;
        this.gameId = gameId;
        this.rating = rating;
        this.reviewText = reviewText;
        this.reviewDate = reviewDate;
    }

    public long getReviewId() { return reviewId; }
    public String getUserSid() { return userSid; }
    public int getGameId() { return gameId; }
    public double getRating() { return rating; }
    public String getReviewText() { return reviewText; }
    public Date getReviewDate() { return reviewDate; }

    @Override
    public String toString() {
        return String.format("★%.1f - %s (%s)", rating, reviewText, reviewDate);
    }
}
