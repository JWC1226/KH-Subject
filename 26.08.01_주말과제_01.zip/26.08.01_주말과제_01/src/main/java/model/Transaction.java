package model;

import java.sql.Date;

public class Transaction {
    private long txId;
    private double totalAmount;
    private String paymentMethod;
    private Date txDate;

    public Transaction(long txId, double totalAmount, String paymentMethod, Date txDate) {
        this.txId = txId;
        this.totalAmount = totalAmount;
        this.paymentMethod = paymentMethod;
        this.txDate = txDate;
    }

    public long getTxId() { return txId; }
    public double getTotalAmount() { return totalAmount; }
    public String getPaymentMethod() { return paymentMethod; }
    public Date getTxDate() { return txDate; }

    @Override
    public String toString() {
        return String.format("[결제 #%d] $%.2f (%s, %s)", txId, totalAmount, paymentMethod, txDate);
    }
}
