package model;

import java.sql.Date;

public class Game {
    private int gameId;
    private String title;
    private String genre;
    private double price;
    private Date releaseDate;
    private String developer;

    public Game(int gameId, String title, String genre, double price, Date releaseDate, String developer) {
        this.gameId = gameId;
        this.title = title;
        this.genre = genre;
        this.price = price;
        this.releaseDate = releaseDate;
        this.developer = developer;
    }

    public int getGameId() { return gameId; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public double getPrice() { return price; }
    public Date getReleaseDate() { return releaseDate; }
    public String getDeveloper() { return developer; }

    @Override
    public String toString() {
        return String.format("[%d] %s | 장르: %s | 가격: $%.2f | 개발사: %s", gameId, title, genre, price, developer);
    }
}
