package dao;

import config.DBConnection;
import model.User;
import util.PasswordUtil;

import java.sql.*;

public class UserDAO {

    // 회원가입 (비밀번호는 평문 저장하지 않고 해시하여 저장)
    public boolean register(User user) {
        String sql = "INSERT INTO USERS (User_SID, ID, Password, Email, Age, Address, Card_Num) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUserSid());
            pstmt.setString(2, user.getId());
            pstmt.setString(3, PasswordUtil.hash(user.getPassword())); // 해시 저장
            pstmt.setString(4, user.getEmail());
            pstmt.setInt(5, user.getAge());
            pstmt.setString(6, user.getAddress());
            pstmt.setString(7, user.getCardNum());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("회원가입 실패: " + e.getMessage());
            return false;
        }
    }

    // 로그인 (성공 시 User_SID 반환, 실패 시 null)
    public String login(String id, String password) {
        String sql = "SELECT User_SID, Password FROM USERS WHERE ID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("Password");
                    if (PasswordUtil.matches(password, storedHash)) {
                        return rs.getString("User_SID");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("로그인 연동 오류: " + e.getMessage());
        }
        return null;
    }
}
