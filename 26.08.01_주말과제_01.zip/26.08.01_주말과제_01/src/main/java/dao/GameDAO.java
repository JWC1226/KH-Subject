package dao;

import config.DBConnection;
import model.Game;
import model.LibraryEntry;
import model.Review;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GameDAO {

    // 1. 스토어 전체 게임 조회
    public List<Game> getAllGames() {
        List<Game> list = new ArrayList<>();
        String sql = "SELECT * FROM GAMES ORDER BY Game_ID";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapRowToGame(rs));
            }
        } catch (SQLException e) {
            System.err.println("게임 조회 오류: " + e.getMessage());
        }
        return list;
    }

    // 1-1. 단건 게임 조회 (구매 시 정가를 DB 기준으로 재확인하기 위함)
    public Game getGameById(int gameId) {
        String sql = "SELECT * FROM GAMES WHERE Game_ID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gameId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapRowToGame(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("게임 단건 조회 오류: " + e.getMessage());
        }
        return null;
    }

    private Game mapRowToGame(ResultSet rs) throws SQLException {
        return new Game(
            rs.getInt("Game_ID"),
            rs.getString("Title"),
            rs.getString("Genre"),
            rs.getDouble("Price"),
            rs.getDate("Release_Date"),
            rs.getString("Developer")
        );
    }

    // 2. 게임 구매 및 라이브러리 추가 (트랜잭션 적용)
    // 결제 금액은 클라이언트 입력을 신뢰하지 않고, DB에 저장된 현재 가격을 기준으로 계산한다.
    public boolean purchaseGame(String userSid, int gameId, String paymentMethod) {
        Game game = getGameById(gameId);
        if (game == null) {
            System.err.println("구매 실패: 존재하지 않는 게임입니다. (Game_ID=" + gameId + ")");
            return false;
        }
        double amount = game.getPrice();

        String txSql = "INSERT INTO TRANSACTIONS (Tx_ID, User_SID, Total_Amount, Payment_Method, Tx_Date) " +
                       "VALUES (TRANSACTION_SEQ.NEXTVAL, ?, ?, ?, SYSDATE)";
        String libSql = "INSERT INTO USER_LIBRARY (Library_ID, User_SID, Game_ID, Purchase_Date, Playtime_Hours) " +
                        "VALUES (LIBRARY_SEQ.NEXTVAL, ?, ?, SYSDATE, 0)";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // 수동 트랜잭션 전환

            // 2-1. 결제 내역 저장 (시퀀스로 PK 자동 생성 → ID 충돌 위험 제거)
            try (PreparedStatement pstmt1 = conn.prepareStatement(txSql)) {
                pstmt1.setString(1, userSid);
                pstmt1.setDouble(2, amount);
                pstmt1.setString(3, paymentMethod);
                pstmt1.executeUpdate();
            }

            // 2-2. 사용자 라이브러리에 저장 (시퀀스로 PK 자동 생성)
            try (PreparedStatement pstmt2 = conn.prepareStatement(libSql)) {
                pstmt2.setString(1, userSid);
                pstmt2.setInt(2, gameId);
                pstmt2.executeUpdate();
            }

            conn.commit(); // 트랜잭션 성공
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            System.err.println("구매 트랜잭션 실패 (Rollback 처리): " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    // 2-1. 사용자 라이브러리 조회 (보유 게임 목록)
    public List<LibraryEntry> getUserLibrary(String userSid) {
        List<LibraryEntry> list = new ArrayList<>();
        String sql = "SELECT l.Library_ID, l.Game_ID, g.Title, l.Purchase_Date, l.Playtime_Hours " +
                     "FROM USER_LIBRARY l JOIN GAMES g ON l.Game_ID = g.Game_ID " +
                     "WHERE l.User_SID = ? ORDER BY l.Purchase_Date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, userSid);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new LibraryEntry(
                        rs.getInt("Library_ID"),
                        rs.getInt("Game_ID"),
                        rs.getString("Title"),
                        rs.getDate("Purchase_Date"),
                        rs.getInt("Playtime_Hours")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("라이브러리 조회 오류: " + e.getMessage());
        }
        return list;
    }

    // 3. 게임 리뷰 작성 (시퀀스로 PK 자동 생성)
    public boolean addReview(String userSid, int gameId, double rating, String text) {
        String sql = "INSERT INTO REVIEWS (Review_ID, User_SID, Game_ID, Rating, Review_Text, Review_Date) " +
                    "VALUES (REVIEW_SEQ.NEXTVAL, ?, ?, ?, ?, SYSDATE)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, userSid);
            pstmt.setInt(2, gameId);
            pstmt.setDouble(3, rating);
            pstmt.setString(4, text);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("리뷰 작성 오류: " + e.getMessage());
            return false;
        }
    }

    // 3-1. 특정 게임의 리뷰 목록 조회
    public List<Review> getReviewsForGame(int gameId) {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM REVIEWS WHERE Game_ID = ? ORDER BY Review_Date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gameId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new Review(
                        rs.getLong("Review_ID"),
                        rs.getString("User_SID"),
                        rs.getInt("Game_ID"),
                        rs.getDouble("Rating"),
                        rs.getString("Review_Text"),
                        rs.getDate("Review_Date")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("리뷰 조회 오류: " + e.getMessage());
        }
        return list;
    }
}
