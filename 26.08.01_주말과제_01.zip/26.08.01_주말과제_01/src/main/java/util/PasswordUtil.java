package util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * 비밀번호 해싱 유틸리티 (SHA-256 + Salt).
 * USERS.Password 컬럼(VARCHAR2(250))에는 "salt$hash" 형태의 문자열로 저장한다.
 *
 * 참고: 실제 서비스 환경이라면 SHA-256보다 BCrypt/Argon2 같은
 * 전용 비밀번호 해시 알고리즘 사용을 권장한다. (학습용 프로젝트 수준에서는 충분함)
 */
public class PasswordUtil {

    private static final String ALGORITHM = "SHA-256";
    private static final int SALT_LENGTH = 16;

    /** 평문 비밀번호를 받아 "salt$hash" 형태의 저장용 문자열을 생성 */
    public static String hash(String plainPassword) {
        try {
            byte[] salt = new byte[SALT_LENGTH];
            new SecureRandom().nextBytes(salt);
            byte[] hashed = digest(plainPassword, salt);

            return Base64.getEncoder().encodeToString(salt) + "$" + Base64.getEncoder().encodeToString(hashed);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("해시 알고리즘을 사용할 수 없습니다: " + e.getMessage(), e);
        }
    }

    /** 로그인 시 입력한 평문 비밀번호와 DB에 저장된 해시값을 비교 */
    public static boolean matches(String plainPassword, String storedValue) {
        try {
            String[] parts = storedValue.split("\\$");
            if (parts.length != 2) {
                return false; // 형식이 다른 경우(예전 평문 데이터 등) 인증 실패 처리
            }
            byte[] salt = Base64.getDecoder().decode(parts[0]);
            byte[] expectedHash = Base64.getDecoder().decode(parts[1]);
            byte[] actualHash = digest(plainPassword, salt);

            return MessageDigest.isEqual(expectedHash, actualHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("해시 알고리즘을 사용할 수 없습니다: " + e.getMessage(), e);
        }
    }

    private static byte[] digest(String plainPassword, byte[] salt) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(ALGORITHM);
        md.update(salt);
        return md.digest(plainPassword.getBytes());
    }
}
